package com.joaochavesjr.geminiapp

import android.os.Bundle
import android.widget.TextView
import android.widget.EditText
import android.widget.Button
import android.widget.Toast

import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.ai.client.generativeai.GenerativeModel
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val etQuestion = findViewById<EditText>(R.id.txtPrompt)
        val btnSubmit = findViewById<Button>(R.id.btnOK)
        //val txtResponse=findViewById<TextView>(R.id.txtResposta)

        btnSubmit.setOnClickListener {
            val question = etQuestion.text.toString()
            Toast.makeText(this, question, Toast.LENGTH_SHORT).show()
            modelCall(question)
        }
    }


    public fun modelCall(prompt: String){

        var textV=findViewById<TextView>(R.id.txtResposta)
        val generativeModel = GenerativeModel(
            modelName = "gemini-2.5-flash",
            apiKey = ""
        )

        MainScope().launch {
            val response = generativeModel.generateContent(prompt)
            textV.setText(response.text)
        }
    }
}