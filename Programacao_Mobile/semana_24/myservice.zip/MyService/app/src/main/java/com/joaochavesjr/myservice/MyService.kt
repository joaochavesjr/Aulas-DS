package com.joaochavesjr.myservice

import android.app.Service
import android.content.Intent
import android.util.Log
import android.os.IBinder
import kotlinx.coroutines.*

class MyService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Default)

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onCreate() {
        super.onCreate()
        Log.d("MyService", ">>>>>> Svc Created!")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {

        Log.d("MyService", "-----> Svc Initiated!")

        serviceScope.launch {
            while (true) {
                Log.d("MyService", "-----> Svc Running...")
                delay(5000)
            }
        }

        return START_STICKY

    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("MyService", "****** Svc Destroyed!")
        serviceScope.cancel()
    }

}