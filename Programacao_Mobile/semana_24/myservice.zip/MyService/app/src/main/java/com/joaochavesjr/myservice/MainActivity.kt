package com.joaochavesjr.myservice

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Toast
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val buttonStart: Button = findViewById(R.id.btnStart)

        buttonStart.setOnClickListener {
            Toast.makeText(this, "Serviço iniciado!", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, MyService::class.java)
            startService(intent)
        }

        val buttonStop: Button = findViewById(R.id.btnStop)

        buttonStop.setOnClickListener {
            Toast.makeText(this, "Serviço interrompido!", Toast.LENGTH_SHORT).show()
            val service_intent = Intent(this, MyService::class.java)
            stopService(service_intent)
        }
    }
}