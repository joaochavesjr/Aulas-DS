package com.joaochavesjr.sgb

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val buttonNext: Button = findViewById(R.id.btnRelatorio)

        buttonNext.setOnClickListener {
            // Crie um Intent para ir para SecondActivity
            val intent = Intent(this, Relatorio::class.java)
            startActivity(intent) // Inicia a SecondActivity
        }

        val buttonImg: Button = findViewById(R.id.btnImage)

        buttonImg.setOnClickListener {
            val intent = Intent(this, Livro::class.java)
            startActivity(intent)
        }
    }
}