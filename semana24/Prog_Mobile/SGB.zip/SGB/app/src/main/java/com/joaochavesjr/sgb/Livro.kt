package com.joaochavesjr.sgb

import android.os.Bundle
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import coil.load
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

// Modelo de dados para a resposta da API
data class ImageUrlResponse(val url: String)

//Interface para a API usando Retrofit
interface ApiService {
    @GET("imagem")
    suspend fun getImageUrl(): ImageUrlResponse
}

class Livro : AppCompatActivity() {
    private lateinit var imageView: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_livro)
        imageView = findViewById(R.id.imageView)

        val retrofit = Retrofit.Builder()
            .baseUrl("http://10.0.2.2:5000/")
            //.baseUrl("http://192.168.10.107:5000/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val apiService = retrofit.create(ApiService::class.java)

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = apiService.getImageUrl()
                val imageUrl = response.url

                withContext(Dispatchers.Main) {
                    imageView.load(imageUrl) {
                        crossfade(true)
                        placeholder(R.drawable.ic_launcher_background)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}