package com.joaochavesjr.sgb


public final data class ApiResponse(
        val Alunos: List<String>,
        val Livros: List<String>,
        val Turma: List<String>,
    )