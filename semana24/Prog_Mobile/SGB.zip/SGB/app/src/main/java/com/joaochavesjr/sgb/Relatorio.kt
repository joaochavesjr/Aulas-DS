package com.joaochavesjr.sgb

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONArray
import org.json.JSONException


class Relatorio : AppCompatActivity() {
    private lateinit var tableLayoutDados: TableLayout
    private lateinit var progressBar: ProgressBar

    // IMPORTANTES:
    // Se estiver usando o EMULADOR Android, 10.0.2.2 é o alias para o localhost do seu computador.
    // Se estiver usando um DISPOSITIVO FÍSICO, substitua "SEU_IP_DO_COMPUTADOR" pelo IP real da sua máquina
    // (Ex: "http://192.168.1.100:5000/api/dados"). O dispositivo e o computador devem estar na mesma rede.
    private val API_URL = "http://10.0.2.2:5000/api/relatorio"
    //private val API_URL = "http://192.168.10.107:5000/api/relatorio"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_relatorio)

        val buttonVoltar: Button = findViewById(R.id.btnVoltar)

        buttonVoltar.setOnClickListener {
            // Crie um Intent para ir para MainActivity
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent) // Volta para o Main
        }

        // Inicializa as views do layout
        tableLayoutDados = findViewById(R.id.tableLayoutDados)
        progressBar = findViewById(R.id.progressBar)

        // Chama a função para buscar os dados da API
        fetchDataFromApi()
    }


    private fun fetchDataFromApi() {
        progressBar.visibility = View.VISIBLE // Mostra o ProgressBar enquanto carrega

        // Cria uma fila de requisições usando Volley
        val queue = Volley.newRequestQueue(this)

        // Cria uma requisição JSON Object (GET)
        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.GET, API_URL, null, // null para o corpo, pois é uma requisição GET
            { response ->
                // Sucesso na requisição
                progressBar.visibility = View.GONE // Esconde o ProgressBar
                try {
                    // Extrai os arrays do objeto JSON
                    val alunosArray: JSONArray = response.getJSONArray("Alunos")
                    val livrosArray: JSONArray = response.getJSONArray("Livros")
                    val turmaArray: JSONArray = response.getJSONArray("Turma")

                    // Adiciona as linhas de dados à tabela
                    addRowsToTable(alunosArray, livrosArray, turmaArray)

                } catch (e: JSONException) {
                    // Erro ao parsear o JSON
                    Log.e("API_ERROR", "Erro ao parsear JSON: ${e.message}")
                    // Limpa a tabela e mostra uma mensagem de erro
                    clearTableAndShowError("Erro ao processar dados da API.")
                }
            },
            { error ->
                // Erro na requisição HTTP
                progressBar.visibility = View.GONE // Esconde o ProgressBar
                Log.e("API_ERROR", "Erro na requisição da API: ${error.message}")
                // Limpa a tabela e mostra uma mensagem de erro
                clearTableAndShowError("Erro ao carregar dados da API. Verifique a conexão e o endereço.")
            }
        )

        // Adiciona a requisição à fila para ser executada
        queue.add(jsonObjectRequest)
    }

    private fun addRowsToTable(alunos: JSONArray, livros: JSONArray, turmas: JSONArray) {
        // Remove todas as linhas existentes, exceto a primeira (cabeçalho)
        // Isso é útil se você for recarregar a tabela ou para garantir que não há dados antigos.
        if (tableLayoutDados.childCount > 1) {
            tableLayoutDados.removeViews(1, tableLayoutDados.childCount - 1)
        }

        val numEntries = alunos.length() // Assumimos que todos os arrays têm o mesmo tamanho

        for (i in 0 until numEntries) {
            val tableRow = TableRow(this).apply {
                layoutParams = TableLayout.LayoutParams(
                    TableLayout.LayoutParams.MATCH_PARENT,
                    TableLayout.LayoutParams.WRAP_CONTENT
                )
                setPadding(8, 8, 8, 8) // Adiciona padding à linha
                // Alternar cores de fundo para melhor legibilidade
                setBackgroundColor(if (i % 2 == 0) Color.parseColor("#F5F5F5") else Color.WHITE)
            }

            // TextView para Aluno
            val tvAluno = TextView(this).apply {
                text = alunos.getString(i)
                layoutParams = TableRow.LayoutParams(
                    TableRow.LayoutParams.WRAP_CONTENT,
                    TableRow.LayoutParams.WRAP_CONTENT
                ).apply {
                    weight = 1.0f // Faz com que ocupe o espaço disponível
                    gravity = Gravity.START
                    marginEnd = 16.dpToPx() // Margem entre as colunas
                }
                textSize = 14f
                setTextColor(Color.BLACK)
            }
            tableRow.addView(tvAluno)

            // TextView para Livro
            val tvLivro = TextView(this).apply {
                text = livros.getString(i)
                layoutParams = TableRow.LayoutParams(
                    TableRow.LayoutParams.WRAP_CONTENT,
                    TableRow.LayoutParams.WRAP_CONTENT
                ).apply {
                    weight = 1.0f
                    gravity = Gravity.START
                    marginEnd = 16.dpToPx()
                }
                textSize = 14f
                setTextColor(Color.BLACK)
            }
            tableRow.addView(tvLivro)

            // TextView para Turma
            val tvTurma = TextView(this).apply {
                text = turmas.getString(i)
                layoutParams = TableRow.LayoutParams(
                    TableRow.LayoutParams.WRAP_CONTENT,
                    TableRow.LayoutParams.WRAP_CONTENT
                ).apply {
                    weight = 1.0f
                    gravity = Gravity.START
                }
                //setTextSize(14f)
                textSize = 14f

                setTextColor(Color.BLACK)
            }
            tableRow.addView(tvTurma)

            tableLayoutDados.addView(tableRow)
        }
    }

    // Função auxiliar para converter dp para pixels
    private fun Int.dpToPx(): Int {
        return (this * resources.displayMetrics.density + 0.5f).toInt()
    }

    // Função para limpar a tabela e exibir uma mensagem de erro
    private fun clearTableAndShowError(errorMessage: String) {
        if (tableLayoutDados.childCount > 1) {
            tableLayoutDados.removeViews(1, tableLayoutDados.childCount - 1)
        }
        val errorRow = TableRow(this)
        val errorTextView = TextView(this).apply {
            text = errorMessage
            layoutParams = TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT).apply {
                span = 3 // Faz com que o TextView ocupe 3 colunas
            }
            gravity = Gravity.CENTER
            setPadding(16, 16, 16, 16)
            setTextColor(Color.RED)
            textSize = 16f
        }
        errorRow.addView(errorTextView)
        tableLayoutDados.addView(errorRow)
    }
}
